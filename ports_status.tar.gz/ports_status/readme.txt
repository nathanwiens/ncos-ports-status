Application Name
================
ports_status


Application Version
===================
0.7


NCOS Devices Supported
======================
ALL


External Requirements
=====================


Application Purpose
===================
This application will set the device description to visually show
the up/down status of modem and ethernet ports.


Expected Output
===============
Description updated
Log printed

