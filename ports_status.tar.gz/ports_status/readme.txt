Application Name
================
ports_status


Application Version
===================
1.30


NCOS Devices Supported
======================
ALL


External Requirements
=====================


Application Purpose
===================
This application will set the device description to visually show
the LAN/WAN/WWAN/Modem/IP Verify status


Expected Output
===============
Description updated every 5 seconds
Log printed

